package br.com.fiap.concessionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPjCp2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
